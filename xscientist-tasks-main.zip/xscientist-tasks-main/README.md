# xScientist Internship Entrance Assignments

## Project directories
- `apps/frontend-assignment` - Front-end assignment's implementation.

## Deployments
- Front-end Assignment: [GitHub Pages](https://proghax333.github.io/xscientist-tasks/apps/frontend-assignment/index.html)
